import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tjhaz/core/database/local/shared_prefrences_helper.dart';
import 'package:tjhaz/feature/favorite/logic/add_or_remove_to_favorite_states.dart';
import '../../../../core/widgets/box_icon_button.dart';
import '../../logic/add_or_remove_to_favorite_cubit.dart';
import '../../logic/get_all_favorite_cubit.dart';

class AddToFavorite extends StatefulWidget {
  final String id;
  const AddToFavorite({super.key, required this.id});

  @override
  State<AddToFavorite> createState() => _AddToFavoriteState();
}

class _AddToFavoriteState extends State<AddToFavorite> {
  late bool isFavorite;

  @override
  void initState() {
    super.initState();
    // Initialize the favorite status based on the current favorites list
    isFavorite = context.read<GetAllFavoriteCubit>().allFavorites.any((element) => element.id == widget.id);
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<AddOrRemoveToFavoriteCubit, AddOrRemoveToFavoriteStates>(
      listener: (context, state) {
        if (state is AddOrRemoveToFavoriteSuccess) {
          context.read<GetAllFavoriteCubit>().get();

        } else if (state is AddOrRemoveToFavoriteFailure) {
          // Handle failure state if needed
        }
      },
      child: FavouriteIcon(
        isFavorite: isFavorite,
        onTap: () async {
          setState(() {
            isFavorite = !isFavorite;
          });

          // Add or remove from favorites using the Cubit
          await context.read<AddOrRemoveToFavoriteCubit>().addToFavorite(entertainmentID: widget.id);

          // Optionally, update the full favorites list after the operation
          if (context.mounted) {
          }
        },
      ),
    );
  }
}
