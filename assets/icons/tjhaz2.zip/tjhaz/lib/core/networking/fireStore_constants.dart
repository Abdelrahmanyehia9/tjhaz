class FireStoreConstants{

 static const String userCollection = "users" ;






}