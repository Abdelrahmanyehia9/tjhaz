
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CardSizes{

  static Size  tripCard = Size( 175.w, 256.h) ;
  static Size  squareCard = Size( 168.w, 168.h) ;









}