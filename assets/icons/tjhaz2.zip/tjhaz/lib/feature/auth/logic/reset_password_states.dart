abstract class ResetPasswordStates{}
class ResetPasswordStatesInitial extends ResetPasswordStates{}
class ResetPasswordStatesSuccess extends ResetPasswordStates{}
class ResetPasswordStatesFailure extends ResetPasswordStates{}
