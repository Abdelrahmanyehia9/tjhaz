package com.example.tjhaz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
